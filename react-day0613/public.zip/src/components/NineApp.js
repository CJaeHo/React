import React,{} from "react";
import '../App.css';

const NineApp = () => {
    return (
        <div>
            <h3 className = "alert alert-danger">NineApp 컴포넌트</h3>
        </div>
    )
}

export default NineApp;