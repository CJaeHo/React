import React from "react";
import '../App.css';

const Board=()=>{




    return (
        <div>
            <h1>Board</h1>
        </div>
    )
}

export default Board;