export {default as About} from './About';
export {default as Main} from './Main';
export {default as Menu} from './Menu';
export {default as Title} from './Title';
export {default as Info} from './Info';