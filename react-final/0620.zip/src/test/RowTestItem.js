import React from "react";
import '../App.css';
import {useNavigate} from 'react-router-dom';
import axios from "axios";

const RowTestItem = () => {

    // URL 전역변수 사용

    // 경로 이동

    // 삭제함수


    return (
        <div>
            
        </div>
    );
};

export default RowTestItem;